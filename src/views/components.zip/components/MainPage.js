import React, {Component} from 'react';



class List extends Component {
    render() {

        return (
            <div>placeholder for list</div>
        )
    }
}

export default List;