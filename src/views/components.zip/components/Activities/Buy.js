import React, {Component} from 'react';



class Buy extends Component {
    render() {

        return (
            <div>This is a generic placeholder!</div>
        )
    }
}

export default Buy;